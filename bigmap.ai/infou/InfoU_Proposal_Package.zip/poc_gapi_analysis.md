# InfoU GAPI32.DLL 내보내기 함수(Export) 분석 및 실전 PoC

본 문서는 InfoU의 핵심 통신 라이브러리 `GAPI32.DLL`의 기술적 분석과 실전 호출 가능성을 검증한 PoC(Proof of Concept) 보고서입니다.

---

## 1. DLL 분석 방법론

### 분석 도구
```
# 방법 1: Visual Studio Developer Command Prompt
dumpbin /exports c:\InfoU\bin\GAPI32.DLL

# 방법 2: Python ctypes를 통한 동적 로드 테스트
python -c "import ctypes; dll = ctypes.WinDLL(r'c:\InfoU\bin\GAPI32.DLL'); print('Loaded successfully')"

# 방법 3: Dependency Walker (depends.exe) 또는 Dependencies (오픈소스)
# GUI에서 DLL을 열면 Export/Import 함수 목록 확인 가능
```

## 2. GAPI32.DLL 추정 기능 분석

`GAPI32.DLL`은 파일명(**G**eneral **API**)과 InfoU 아키텍처를 고려할 때, InfoU의 **태그 데이터 읽기/쓰기를 위한 범용 인터페이스**로 추정됩니다.

### 추정되는 핵심 Export 함수:
```c
// 연결 관리
HANDLE GAPI_Connect(LPCSTR serverName);
BOOL   GAPI_Disconnect(HANDLE hConn);

// 태그 읽기/쓰기
BOOL   GAPI_ReadTag(HANDLE hConn, LPCSTR tagName, VARIANT* pValue);
BOOL   GAPI_WriteTag(HANDLE hConn, LPCSTR tagName, VARIANT value);

// 다중 태그 일괄 처리
BOOL   GAPI_ReadMultipleTags(HANDLE hConn, LPCSTR* tagNames, int count, VARIANT* pValues);
BOOL   GAPI_WriteMultipleTags(HANDLE hConn, LPCSTR* tagNames, int count, VARIANT* values);

// 상태 조회
int    GAPI_GetLastError();
BOOL   GAPI_IsConnected(HANDLE hConn);
```

## 3. 실전 PoC 코드 (Python)

```python
"""
InfoU GAPI32.DLL Bridge PoC - Python 기반 태그 제어 프로토타입
작성자: 하태호 (bigmap@bigmap.ai)
목적: InfoU의 기존 DLL을 현대적 언어에서 직접 호출할 수 있음을 증명
"""
import ctypes
import os

# === 1단계: DLL 존재 확인 및 로드 ===
dll_path = r"c:\InfoU\bin\GAPI32.DLL"

if not os.path.exists(dll_path):
    print(f"[ERROR] DLL not found: {dll_path}")
else:
    print(f"[OK] DLL found: {dll_path} ({os.path.getsize(dll_path):,} bytes)")
    
    try:
        gapi = ctypes.WinDLL(dll_path)
        print(f"[OK] DLL loaded successfully")
        
        # === 2단계: Export 함수 탐색 ===
        # 실제 함수명은 dumpbin으로 확인 후 매핑
        # 아래는 일반적인 SCADA API 패턴에 기반한 시도
        test_functions = [
            'GAPI_Connect', 'GAPI_ReadTag', 'GAPI_WriteTag',
            'Connect', 'ReadTag', 'WriteTag',
            'GAPIConnect', 'GAPIReadTag', 'GAPIWriteTag',
        ]
        
        found_funcs = []
        for func_name in test_functions:
            try:
                func = getattr(gapi, func_name)
                found_funcs.append(func_name)
                print(f"  [FOUND] {func_name}: {func}")
            except AttributeError:
                pass
        
        if not found_funcs:
            print("  [INFO] 표준 이름 패턴으로는 함수를 찾지 못했습니다.")
            print("  [INFO] dumpbin /exports 또는 Dependencies 도구로 정확한 이름을 확인하세요.")
        
    except OSError as e:
        print(f"[WARN] DLL load failed: {e}")
        print(f"[INFO] 의존성 DLL이 누락되었을 수 있습니다. InfoU가 설치된 환경에서 실행하세요.")

print("\n=== PoC 결론 ===")
print("이 스크립트로 DLL의 로드 가능 여부와 Export 함수 존재 여부를 확인할 수 있습니다.")
print("실제 함수 호출은 Export 함수명 확인 후 ctypes 시그니처 매핑이 필요합니다.")
```

## 4. 검증 실행 방법

```bash
# 1. InfoU가 설치된 환경에서 실행
cd c:\InfoU
python poc_gapi_bridge.py

# 2. Export 함수 확인 (Visual Studio 개발자 명령 프롬프트)
dumpbin /exports c:\InfoU\bin\GAPI32.DLL > gapi_exports.txt
```

## 5. 결론

이 PoC는 **"레거시 DLL을 현대적 언어에서 직접 호출할 수 있다"**는 기술적 원리를 입증합니다. `dumpbin`으로 정확한 Export 함수명을 확인한 후, 안티그래비티가 자동으로 완전한 Python 래퍼 클래스를 생성할 수 있습니다.

---
*작성: 하태호 (bigmap@bigmap.ai) × Antigravity AI*
