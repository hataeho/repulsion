# LS Electric InfoU SCADA Developer Workspace

이 폴더는 LS Electric의 InfoU SCADA 시스템 운영 및 개발을 위한 최상위 디렉토리입니다.

## 📁 주요 폴더 구조
- **`bin/`**: 시스템 핵심 런타임 (실행파일, 통신 드라이버, ActiveX 컨트롤)
- **`CodeBase/`**: 공통 서비스 및 데이터베이스 인터페이스
- **`Project/`**: 개별 프로젝트 데이터 (화면 `.ivd`, 스크립트 `.sba`, 설정)
- **`Log/`**: 시스템 및 프로젝트 실행 로그

## 🛠 주요 모듈 및 태스크 분류
- **통신 드라이버 (I/O Drivers)**: `bin/iu[Protocol].exe` (예: `iuXGIEnet.exe`, `iuModbusTCP.exe`)
- **감시 및 제어 UI**: `bin/InfoU.exe`, `bin/InfoUMDesigner.exe`
- **데이터 분석 및 트랜드**: `bin/iuTrendViewer`, `bin/iuGraphPro.ocx`

## 📈 그래프 작성 및 API 활용
InfoU는 프로젝트 내 스크립트(`Project/[Project]/Script/*.sba`)를 통해 제어가 가능합니다.
- **Graph 컴포넌트**: `iuGraphPro.ocx`, `iuTrendViewer`, `iuPatternTrend`
- **활용 팁**: 
  - 화면(`ivd`)에 배치된 그래프 객체는 스크립트에서 속성(Properties)과 메서드(Methods)로 제어할 수 있습니다.
  - 세부 API 정보는 `bin/InfoU_Manual_KOR.pdf`를 참조하십시오.

## 🤝 협업 가이드
1. **모듈 추가**: 새로운 통신 드라이버나 리소스는 `bin/` 폴더의 규칙을 따릅니다.
2. **프로젝트 관리**: 다른 개발자와 협업 시 `Project/` 하위의 자신의 프로젝트 폴더 내에서 작업하여 간섭을 방지하십시오.
이 분석 프로젝트는 InfoU의 발전을 바라는 한 명의 소비자이자 개발자로서, 어떠한 경제적 대가나 보상 없이 모든 InfoU 사용자의 편의성 증대를 위해 수행되었습니다. 본인은 안티그래비티(AI)를 통한 개인적 과제 해결에 만족하며, 이 분석 결과가 LS ELECTRIC의 공식적인 개발 방향 정립에 긍정적인 기여를 하기를 희망합니다.
3. **분석 보고서**: 자세한 시스템 분석 내용은 `analysis_report.md`를 확인하십시오.

---
*Created by Antigravity AI for Future Developers.*
