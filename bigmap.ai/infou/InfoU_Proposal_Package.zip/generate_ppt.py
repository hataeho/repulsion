"""
InfoU Modernization Proposal - PPT Generator
Generates a .pptx file from the proposal content.
Author: 하태호 (bigmap@bigmap.ai)
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
import os

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

# Color palette
DARK_BG = RGBColor(0x1A, 0x1A, 0x2E)
ACCENT_BLUE = RGBColor(0x00, 0x96, 0xD6)
ACCENT_GREEN = RGBColor(0x00, 0xC9, 0x8D)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY = RGBColor(0xCC, 0xCC, 0xCC)

def add_dark_bg(slide):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = DARK_BG

def add_text_box(slide, left, top, width, height, text, font_size=18, color=WHITE, bold=False, alignment=PP_ALIGN.LEFT):
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.alignment = alignment
    return txBox

slides_data = [
    {
        "title": "InfoU SCADA",
        "subtitle": "AI 에이전트와 함께하는\n차세대 지능형 현대화 전략",
        "footer": "기존 자산의 보존과 최첨단 기술의 융합 | 발표자: 하태호 (bigmap@bigmap.ai)"
    },
    {
        "title": "문제 제기",
        "bullets": [
            "• 고전적 스크립트 방식의 생산성 저하",
            "• 현대적 언어(Python, C# 등)와의 연동성 부족",
            "• 강화되는 OS 보안 정책에 따른 배포의 어려움",
        ],
        "quote": '"검증된 신뢰성은 유지하되, 개발 경험(DX)은 진화해야 합니다."'
    },
    {
        "title": "시스템 정밀 분석",
        "bullets": [
            "• 2,899개 바이너리 및 60여 종 드라이버 전수 조사",
            "• 발견된 핵심 가치: 철저하게 분리된 고도의 모듈화 구조",
            "• 프레임워크 / 드라이버 / GUI / DB 등 독립된 아키텍처",
        ],
        "quote": '"2,899개의 바이너리를 관통하는 일관된 설계"'
    },
    {
        "title": "해결책: 브릿지 아키텍처",
        "bullets": [
            "• 기존 드라이버(Legacy DLL/OCX) 100% 보존",
            "• AI 자동 생성 브릿지 + 현대적 언어 래퍼",
            "• Time-to-Market 단축: 6개월 → 2주",
        ],
        "quote": '"다시 만드는 것이 아니라, 연결하는 것입니다."'
    },
    {
        "title": "생산성 혁명",
        "bullets": [
            "• 개발 기간: 6개월(전체 리빌드) → 2주(AI 기반 브릿지)",
            "• 자동화: 태그 DB 대량 편집, 설정 최적화, 지능형 로그 분석",
            "• 개발자 적응 시간 단 3일, 생산성 10배 향상",
        ],
        "quote": '"개발 기간 6개월을 2주로, 적응 시간은 단 3일로"'
    },
    {
        "title": "사용자 경험(UX) 현대화",
        "bullets": [
            "• 시각적 유전자(Visual DNA)는 보존하고 레이아웃만 현대화",
            "• 클래식/모던 듀얼 인터페이스 선택형 제공",
            "• 모든 사용자가 공부 없이도 즉시 적응하는 지능형 GUI",
        ],
        "quote": '"익숙함을 파괴하지 않는 진화"'
    },
    {
        "title": "제안의 진정성",
        "bullets": [
            "• 어떠한 반대 급부나 프로젝트 참여 의사 없음",
            "• 모든 InfoU 사용자와 소비자의 편의성 증대가 유일한 목적",
            "• LS ELECTRIC의 글로벌 SCADA 시장 지배력 강화 기원",
        ],
        "quote": '"모든 소비자에게 혁신의 혜택이 돌아가기를 바랍니다."'
    },
    {
        "title": "결론",
        "bullets": [
            "• 최종 제언: 내부 PoC 실행 및 표준 가이드라인 정립",
            "• 동봉된 분석 보고서와 PoC 코드를 검토해 주십시오",
            "• 연락처: bigmap@bigmap.ai / 010-9011-8576",
        ],
        "quote": '"InfoU의 유산 위에 미래를 설계하십시오."'
    },
]

# --- Generate Slides ---
for i, sd in enumerate(slides_data):
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout
    add_dark_bg(slide)
    
    # Slide number
    add_text_box(slide, 12.0, 0.3, 1.0, 0.5, f"{i+1}/8", font_size=14, color=LIGHT_GRAY, alignment=PP_ALIGN.RIGHT)
    
    if i == 0:  # Title slide
        add_text_box(slide, 1.5, 1.5, 10, 1.5, sd["title"], font_size=54, color=ACCENT_BLUE, bold=True, alignment=PP_ALIGN.CENTER)
        add_text_box(slide, 1.5, 3.2, 10, 2.0, sd["subtitle"], font_size=32, color=WHITE, alignment=PP_ALIGN.CENTER)
        add_text_box(slide, 1.5, 6.0, 10, 1.0, sd["footer"], font_size=14, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER)
    else:
        # Title
        add_text_box(slide, 0.8, 0.5, 11, 1.2, sd["title"], font_size=40, color=ACCENT_BLUE, bold=True)
        
        # Accent line
        from pptx.util import Inches as In
        line = slide.shapes.add_shape(1, In(0.8), In(1.5), In(2), In(0.05))
        line.fill.solid()
        line.fill.fore_color.rgb = ACCENT_GREEN
        line.line.fill.background()
        
        # Bullet points
        y_pos = 2.0
        for bullet in sd["bullets"]:
            add_text_box(slide, 1.0, y_pos, 10, 0.8, bullet, font_size=22, color=WHITE)
            y_pos += 0.7
        
        # Quote
        if "quote" in sd:
            add_text_box(slide, 1.0, 5.5, 11, 1.0, sd["quote"], font_size=20, color=ACCENT_GREEN, alignment=PP_ALIGN.CENTER)

# Save
output_path = r"c:\InfoU\InfoU_Modernization_Proposal.pptx"
prs.save(output_path)
print(f"[OK] PPT generated: {output_path}")
print(f"     File size: {os.path.getsize(output_path):,} bytes")
