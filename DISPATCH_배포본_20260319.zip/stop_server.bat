@echo off
title DISPATCH Server Stop
echo 서버 프로세스(python.exe)를 종료합니다...
taskkill /F /IM python.exe
echo.
echo 백그라운드 서버가 안전하게 종료되었습니다.
pause
