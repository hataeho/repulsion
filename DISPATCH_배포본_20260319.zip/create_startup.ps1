$wshell = New-Object -ComObject WScript.Shell
$startupFolder = $env:APPDATA + "\Microsoft\Windows\Start Menu\Programs\Startup"
$shortcut = $wshell.CreateShortcut("$startupFolder\DISPATCH_Server.lnk")
$shortcut.TargetPath = "wscript.exe"
$shortcut.Arguments = """C:\REPULSION\DISPATCH\start_background.vbs"""
$shortcut.WorkingDirectory = "C:\REPULSION\DISPATCH"
$shortcut.Save()
Write-Host "Startup shortcut created at: $startupFolder\DISPATCH_Server.lnk"
